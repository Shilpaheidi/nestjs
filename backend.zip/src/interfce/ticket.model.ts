export interface Ticket {
    id: number;
    title: string;
    status: string;
    description: string;
  }
  

  export  interface getTicket {
    id: string;
    title: string;
    status: string;
    description: string;
  }
 
  
  
  
  
  